package Day6_inheritance;

public class InheritanceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChildClass ch = new ChildClass();
		ch.setAmt(20000);
		System.out.println(ch);
	}
}
