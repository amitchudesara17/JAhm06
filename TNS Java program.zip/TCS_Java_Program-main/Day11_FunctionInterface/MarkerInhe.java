package Day11_FunctionInterface;

public interface MarkerInhe extends Gretting{

}
