package color;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * Employee e = new Employee();
		 * 
		 * e.setEname("Om"); e.setSal(4000);
		 */
		 
		  color c = new color(); 
		  
		  c.setCname("Red");
		  System.out.println(c);
		  
		  c.setCname("Bue");
		  System.out.println(c);
	}
}

