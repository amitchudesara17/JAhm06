package Day22;
@FunctionalInterface

public interface lambda {
	void g1();
}
interface Cal1{ void getTotal();
}
interface Cal2{ int getSquare(int no);
}
