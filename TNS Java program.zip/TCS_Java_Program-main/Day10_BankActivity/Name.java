package Day10_Bank_Activity;

public interface Name {
	String name = "yuvraj";
	
	void printname();
}
