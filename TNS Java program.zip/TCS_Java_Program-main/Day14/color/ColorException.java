package color;

public class ColorException extends Exception {
	
	public ColorException(String msg) {
			// TODO Auto-generated constructor stub
		super(msg);
	}
}
