package color;

public class SalaryException extends Exception {

	public SalaryException(String msg) {
		super(msg);
	}
}

