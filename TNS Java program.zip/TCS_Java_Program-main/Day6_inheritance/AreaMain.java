package Day6_inheritance;

public class AreaMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Square s = new Square(12,17,4);
		
		System.out.println(s);
	}

}
