package Day11_CovariantType;

public class Parent {
	public Object show(){
		Object ob = null;
		System.out.println("Parent class");
		return ob;
	}
}
