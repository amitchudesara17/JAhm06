package Day2;
public class emp1 {
 public static void main(String[] args)
 {  // TODO Auto-generated method stub
  emp e1 = new emp();
  emp e2 = new emp();  
  
  e1.setNo(101);  
  e1.setName("yuvraj");
  
  e2.setNo(102);
  e2.setName("om");  
  System.out.println("Employee 1 : "+e1); 
  System.out.println("Employee 2 : "+e2);
 }
}