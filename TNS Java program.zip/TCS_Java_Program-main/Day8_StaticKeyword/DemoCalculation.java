package Day8_Static_Keyword;

public class DemoCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator c1 = new Calculator();
		System.out.println(c1);
		
		Calculator c2 = new Calculator();
		System.out.println(c2);
		
		Calculator c3 = new Calculator();
		System.out.println(c3);
		
		System.out.println(Calculator.count);
	}

}
